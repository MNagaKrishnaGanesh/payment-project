function generateTransactionId() {
    return 'TXN' + Math.floor(Math.random() * 1000000);
}

function processPayment() {
    document.getElementById("loader").style.display = "block";
    setTimeout(() => {
        document.getElementById("loader").style.display = "none";
        document.getElementById("receipt").style.display = "block";
        document.getElementById("rName").innerText = document.getElementById("name").value;
        document.getElementById("rAmount").innerText = document.getElementById("amount").value;
        const txnId = generateTransactionId();
        document.getElementById("transactionId").innerText = txnId;
        alert("Payment Successful! Thank you for your transaction.");
    }, 3000);
}

function downloadReceipt() {
    const name = document.getElementById("rName").innerText;
    const amount = document.getElementById("rAmount").innerText;
    const txnId = document.getElementById("transactionId").innerText;
    
    const receiptContent = `Payment Receipt\n\nName: ${name}\nAmount: ₹${amount}\nTransaction ID: ${txnId}\nStatus: Success ✅`;
    
    const blob = new Blob([receiptContent], { type: "text/plain" });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "Payment_Receipt.txt";
    link.click();
}

function resetForm() {
    document.getElementById("paymentForm").reset();
    document.getElementById("receipt").style.display = "none";
}
